#define PRODUCED 100      // number of produced values
#define FILE_SIZE 10        // size of files
#define MAX_THREADS 20     // number of threads
#define PROCESSING 100000  // processing delay
#define CYCLES 1000

#define PRINT(s,v) //fprintf (stderr,s,v)

