#define PRODUCED 5000       // number of produced values
#define FILE_SIZE 20        // size of files
#define MAX_THREADS 5      // number of threads
#define PROCESSING 1000000  // processing delay

#define PRINT(s,v) fprintf (stderr,s,v)

