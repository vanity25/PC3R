#include "fthread.h"
#include <stdio.h>


typedef struct paquet {
    char *contenu;
} paquet;

typedef struct tapis {
    paquet *paquets;
    int capacite;
    int head, tail, count;

    ft_event_t ev_non_vide;
    ft_event_t ev_non_plein;
} tapis_t;

tapis_t *tapis_create(ft_scheduler_t sched, int cap){
    tapis_t *t = malloc(sizeof(*t));
    t->paquets = malloc(sizeof(paquet) * cap);
    t->capacite = cap;
    t->head = t->tail = t->count = 0;
    t->ev_non_vide  = ft_event_create(sched);
    t->ev_non_plein = ft_event_create(sched);
    
    return t;
}

tapis_t * tapis_enfiler()